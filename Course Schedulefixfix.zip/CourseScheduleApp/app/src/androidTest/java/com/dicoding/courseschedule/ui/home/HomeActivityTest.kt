package com.dicoding.courseschedule.ui.home

import android.view.View
import android.view.ViewGroup
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.intent.Intents
import androidx.test.espresso.intent.matcher.IntentMatchers
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import com.dicoding.courseschedule.R
import com.dicoding.courseschedule.ui.add.AddActivity
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers
import org.hamcrest.TypeSafeMatcher
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
class HomeActivityTest {

    @Rule
    @JvmField
    var _ActivityTestRule = ActivityTestRule(HomeActivity::class.java)

    @Test
    fun homeActivityTest() {
        val action = Espresso.onView(
            Matchers.allOf(
                withId(R.id.action_add), ViewMatchers.withContentDescription("Add"),
                position(
                    position(withId(R.id.action_bar), 1),
                    0
                ),
                ViewMatchers.isDisplayed()
            )
        )

        Intents.init()
        action.perform(ViewActions.click())
        Intents.intended(IntentMatchers.hasComponent(AddActivity::class.java.name))
        Intents.release()
    }

    private fun position(
        parentMatcher: Matcher<View>, position: Int): Matcher<View> {
        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("at position $position in parent")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
