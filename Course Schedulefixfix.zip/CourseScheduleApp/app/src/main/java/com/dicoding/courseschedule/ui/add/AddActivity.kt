package com.dicoding.courseschedule.ui.add

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.dicoding.courseschedule.R
import com.dicoding.courseschedule.data.DataRepository
import com.dicoding.courseschedule.util.TimePickerFragment
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddActivity : AppCompatActivity(), TimePickerFragment.DialogTimeListener {
    private var timepicker: String? = null
    private var start = ""
    private var end = ""
    private lateinit var viewModel: AddCourseViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        timepicker = TAG_START
        viewModel = AddCourseViewModel(
            DataRepository.getInstance(applicationContext)!!
        )
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
    fun showTimePicker(view: View) {
        val dialog = TimePickerFragment()
        when (view.id) {
            R.id.iv_start_time -> {
                timepicker = TAG_START
                dialog.show(supportFragmentManager, timepicker)
            }
            R.id.iv_end_time -> {
                timepicker = TAG_END
                dialog.show(supportFragmentManager, timepicker)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onDialogTimeSet(tag: String?, hour: Int, minute: Int) {
        if (timepicker == TAG_START) {
            start(hour, minute)
//            start = String.format("%02d", hour) + ":" + String.format("%02d", minute)
//            findViewById<TextView>(R.id.tv_start_time).text = start
        } else if (timepicker == TAG_END) {
            end(hour, minute)
//            end = String.format("%02d", hour) + ":" + String.format("%02d", minute)
//            findViewById<TextView>(R.id.tv_end_time).text = end
        }
    }
    private fun start(hour: Int, minute: Int){
        start = String.format("%02d", hour) + ":" + String.format("%02d", minute)
        findViewById<TextView>(R.id.tv_start_time).text = start
    }
    private fun end(hour: Int, minute: Int){
        end = String.format("%02d", hour) + ":" + String.format("%02d", minute)
        findViewById<TextView>(R.id.tv_end_time).text = end
    }

    private fun DayName(dayName : String) : Int {
        return when(dayName) {
            "Monday" -> 1
            "Tuesday" -> 2
            "Wednesday" -> 3
            "Thursday" -> 4
            "Friday" -> 5
            "Saturday" -> 6
            "Sunday" -> 7
            else -> 1
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_insert -> {
                val day = findViewById<Spinner>(R.id.spinnerDay).selectedItem.toString()
                val dayNumber = DayName(dayName = day)
                viewModel.insertCourse(
                    findViewById<EditText>(R.id.add_ed_course_name).text.toString(),
                    dayNumber,
                    start,
                    end,
                    findViewById<EditText>(R.id.ed_lecturer_name).text.toString(),
                    findViewById<EditText>(R.id.ed_note).text.toString()
                )
                finish()
                viewModel.saved.observe(this, { event ->
                    event.getContentIfNotHandled()?.let { isSaved ->
                        if (isSaved) {
                            showToast(
                                applicationContext,
                                "New schedule successfull added"
                            )
                        }
                    }
                })
            }
            android.R.id.home -> finish()
        }
        return super.onOptionsItemSelected(item)
    }
    fun showToast(context: Context, message: String){
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
    companion object {
        const val TAG_START = "time_Picker_is_Start"
        const val TAG_END = "time_Picker_is_End"
    }

}